import pandas as pd


data = pd.read_csv('eda.txt',index_col =[0] )
